﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace YourWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NotificationController : ControllerBase
    {
        private readonly string _connectionString;

        public NotificationController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // GET: api/notification
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Notification>>> GetNotifications()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var command = new SqlCommand("SELECT * FROM Notifications ORDER BY Timestamp DESC", connection);
                var notifications = new List<Notification>();

                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        notifications.Add(new Notification
                        {
                            Id = (int)reader["Id"],
                            Message = reader["Message"].ToString(),
                            Timestamp = (DateTime)reader["Timestamp"],
                            IsRead = (bool)reader["IsRead"]
                        });
                    }
                }

                return Ok(notifications);
            }
        }

        // POST: api/notification
        [HttpPost]
        public async Task<IActionResult> PostNotification(Notification notification)
        {
            if (ModelState.IsValid)
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var command = new SqlCommand("INSERT INTO Notifications (Message, Timestamp, IsRead) VALUES (@Message, @Timestamp, @IsRead)", connection);
                    command.Parameters.AddWithValue("@Message", notification.Message);
                    command.Parameters.AddWithValue("@Timestamp", notification.Timestamp);
                    command.Parameters.AddWithValue("@IsRead", notification.IsRead);
                    await command.ExecuteNonQueryAsync();
                }

                return Ok();
            }

            return BadRequest(ModelState);
        }

        // Other endpoints for updating and deleting notifications should be implemented as well.
    }
}
