﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.OracleClient;


namespace QA_Tracker_Api.Main.BLL
{
    public class Db_Connection
    {


        public OracleConnection con = new OracleConnection("Data Source=macuat;User ID=mactech;Password=tech#1234;");
        public OracleCommand cmd = new OracleCommand();
        public OracleConnection Connect()
        {
            if (con.State == System.Data.ConnectionState.Closed)
            {
                con.Open();
            }

            return con;
        }

    }
}
