﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QA_Tracker_Api.Main.Models.RequestModel;
using QA_Tracker_Api.Main.Models.ResponseModel;
using QA_Tracker_Api.Common;
using System.Data;
using System.Data.OracleClient;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Rendering;
using QA_Tracker_Api.Main.Models;
using ClosedXML.Excel;
using System.IO;
using Azure;

namespace QA_Tracker_Api.Main.BLL
{
    public class QueryClass: Db_Connection
    {
        Db_Connection db_ = new Db_Connection();
        public ModelforEmpcodeResponse Fetch_menu_for_Empcode(ModelforEmpcodeRequest req)
        {
            ModelforEmpcodeResponse response = new ModelforEmpcodeResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select a.menu_redirection,a.menu_name from qa_menu_items a ,qa_menu_access b where a.menu_id=b.menu_id and b.emp_code='" + req.Emp_code + "'";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            response.Data = JsonConvert.SerializeObject(dt);

            return response;
        }


        public ProjectModelforFetchCrfidResponse Crf_id_Details()
        {
            ProjectModelforFetchCrfidResponse res = new ProjectModelforFetchCrfidResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();

            cmd.CommandText = "select distinct(t.crf_id) from time_sheet_crf_det t where t.req_status IN(39,10,11)";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
             cmd.Connection.Close();
            List<SelectListItem> clist = new List<SelectListItem>();
            foreach (DataRow item in dt.Rows)
            {

                clist.Add(new SelectListItem { Text = item["crf_id"].ToString(), Value = item["crf_id"].ToString() });
            }

            res.Crf_Id = clist;

            return res;
        }
        public ProjectModelforDeatilsofCrfidResponse FetchAllDetailsforCrfId(ProjectModelforDeatilsofCrfidRequest req)
        {
            ProjectModelforDeatilsofCrfidResponse response = new ProjectModelforDeatilsofCrfidResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.crf_id,t.client, c.firm_name,t.project,p.type_name,t.crf_desc,t.tl_id,e.emp_name tl_name,m.assign_to,f.emp_name developer from time_sheet_crf_det t ,time_sheet_master_new m,time_sheet_cl_dtl c,time_sheet_project p,employee_master e,employee_master f where c.firm_id = t.client and m.soft_req_id = t.crf_id and p.type_id = t.project and e.emp_code = t.tl_id and f.emp_code = m.assign_to and t.req_status in(39, 10, 11) and t.crf_id = '" + req.Crf_Id+"'";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            response.Data = JsonConvert.SerializeObject(dt);
            return response;
        }
        public PriorityModelResponse Add_Priority(PriorityModelRequest requ)
        {
            int idval = 0;
            PriorityModelResponse _priorityModelResponse = new PriorityModelResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select max(priority_id) from qa_priority_master";
            var a = cmd.ExecuteScalar();

            if (a == null)
            {
                idval = 1;
            }
            else
            {
                idval = Convert.ToInt32(a) + 1;
            }
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select count(*) from qa_priority_master where UPPER(priority_name)=UPPER('" + requ.Priority_name + "')";
            var exitsval = cmd.ExecuteScalar();

            int co = Convert.ToInt32(exitsval);
            cmd.Connection.Close();
            if (co > 0)
            {
                _priorityModelResponse.Result = "3";
                return _priorityModelResponse;
            }
            else
            {
                cmd.Connection = db_.Connect();
                cmd.CommandText = "Insert into  qa_priority_master(priority_id,priority_name) values('" + idval + "',UPPER('" + requ.Priority_name + "'))";
                var i = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                if (i == 1)
                {
                    _priorityModelResponse.Result = "1";
                }
                else
                {
                    _priorityModelResponse.Result = "0";
                }
            }


            // modelforSeverityResponse.Data = JsonConvert.SerializeObject(dt);

            return _priorityModelResponse;
        }
        public PriorityFetchingResponse PriorityDetailsforAdmin()
        {
            PriorityFetchingResponse res = new PriorityFetchingResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.priority_id,t.priority_name from qa_priority_master t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            List<SelectListItem> clist = new List<SelectListItem>();

            foreach (DataRow item in dt.Rows)
            {

                clist.Add(new SelectListItem { Text = item["priority_name"].ToString(), Value = item["priority_id"].ToString() });
            }
            res.Priority_name = clist;

            return res;
        }


        public PriorityFetchingfordeleteResponse PriorityDetailsforAdminfordelete()
        {
            PriorityFetchingfordeleteResponse res = new PriorityFetchingfordeleteResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.priority_id,t.priority_name from qa_priority_master t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            List<SelectListItem> clist = new List<SelectListItem>();

            foreach (DataRow item in dt.Rows)
            {

                clist.Add(new SelectListItem { Text = item["priority_name"].ToString(), Value = item["priority_id"].ToString() });
            }
            res.Priority_name = clist;

            return res;
        }
        public PriorityEditDetailsResponse FetchPriorityDetailWithID(PriorityEditDetailsRequest req)
        {
            PriorityEditDetailsResponse response = new PriorityEditDetailsResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "Select * from qa_priority_master t where t.priority_id='"+req.Priority_id+"'";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            response.Priority_id =Convert.ToInt32(dt.Rows[0][0]);
            response.Priority_name= dt.Rows[0][1].ToString();
            
            return response;
        }
        
        public PriorityUpdateResponse getUpdatePriority(PriorityUpdateRequest req)
        {
            PriorityUpdateResponse res = new PriorityUpdateResponse();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "UPDATE qa_priority_master SET  priority_name ='" + req.Priority_name + "' WHERE priority_id='" + req.Priority_id + "'";
            var num = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            int j = Convert.ToInt32(num);
            if (j > 0)
            {
                res.Result = 1;
            }
            else
            {
                res.Result = 0;
            }

            return res;
        }
        public PriorityDeleteResponse getDeletePriority(PriorityDeleteRequest req)
        {
            PriorityDeleteResponse res = new PriorityDeleteResponse();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "DELETE FROM qa_priority_master m WHERE m.priority_id = '"+req.Priority_id+"'";
            var num = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            int j = Convert.ToInt32(num);
            if (j > 0)
            {
                res.Result = 1;
            }
            else
            {
                res.Result = 0;
            }

            return res;
        }
        public TrackerModelResponse Add_Tracker(TrackerModelRequest requ)
        {
            int idval = 0;
            TrackerModelResponse _trackerModelResponse = new TrackerModelResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select max(tracker_id) from qa_tracker_master";
            var a = cmd.ExecuteScalar();
            if (a == null)
            {
                idval = 1;
            }
            else
            {
                idval = Convert.ToInt32(a) + 1;
            }
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select count(*) from qa_tracker_master where UPPER(tracker_name)=UPPER('" + requ.Tracker_name+ "')";
            var exitsval = cmd.ExecuteScalar();

            int co = Convert.ToInt32(exitsval);
            cmd.Connection.Close();
            if (co > 0)
            {
                _trackerModelResponse.Result = "3";
                return _trackerModelResponse;
            }
            else
            {
                cmd.Connection = db_.Connect();
                cmd.CommandText = "Insert into  qa_tracker_master(tracker_id,tracker_name) values('" + idval + "','" + requ.Tracker_name + "')";
                var i = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                if (i == 1)
                {
                    _trackerModelResponse.Result = "1";
                }
                else
                {
                    _trackerModelResponse.Result = "0";
                }


                // modelforSeverityResponse.Data = JsonConvert.SerializeObject(dt);

                return _trackerModelResponse;
            }
        }
        
        public TrackerFetchingResponse TrackerDetailsforAdmin()
        {
            TrackerFetchingResponse res = new TrackerFetchingResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.tracker_id,t.tracker_name from qa_tracker_master t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            List<SelectListItem> clist = new List<SelectListItem>();

            foreach (DataRow item in dt.Rows)
            {

                clist.Add(new SelectListItem { Text = item["Tracker_name"].ToString(), Value = item["Tracker_id"].ToString() });
            }
            res.Tracker_name = clist;

            return res;
        }
        
        public TrackerEditDetailsResponse FetchTrackerDetailWithID(TrackerEditDetailsRequest req)
        {
            TrackerEditDetailsResponse response = new TrackerEditDetailsResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "Select * from qa_tracker_master t where t.tracker_id='" + req.Tracker_id + "'";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            response.Tracker_id = Convert.ToInt32(dt.Rows[0][0]);
            response.Tracker_name = dt.Rows[0][1].ToString();

            return response;
        }
        
        public TrackerUpdateResponse getUpdateTracker(TrackerUpdateRequest req)
        {
            TrackerUpdateResponse res = new TrackerUpdateResponse();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "UPDATE qa_tracker_master SET  tracker_name ='" + req.Tracker_name + "' WHERE tracker_id='" + req.Tracker_id + "'";
            var num = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            int j = Convert.ToInt32(num);
            if (j > 0)
            {
                res.Result = 1;
            }
            else
            {
                res.Result = 0;
            }

            return res;
        }
        public TrackerFetchingfordeleteResponse TrackerDetailsforAdminfordelete()
        {
            TrackerFetchingfordeleteResponse res = new TrackerFetchingfordeleteResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.tracker_id,t.tracker_name from qa_tracker_master t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            List<SelectListItem> clist = new List<SelectListItem>();

            foreach (DataRow item in dt.Rows)
            {

                clist.Add(new SelectListItem { Text = item["Tracker_name"].ToString(), Value = item["Tracker_id"].ToString() });
            }
            res.Tracker_name = clist;

            return res;
        }

        public TrackerDeleteResponse getDeleteTracker(TrackerDeleteRequest req)
        {
            TrackerDeleteResponse res = new TrackerDeleteResponse();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "DELETE FROM qa_tracker_master m WHERE m.tracker_id = '" + req.Tracker_id + "'";
            var num = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            int j = Convert.ToInt32(num);
            if (j > 0)
            {
                res.Result = 1;
            }
            else
            {
                res.Result = 0;
            }

            return res;
        }
        public AssignTesterResponse fetchallcrfid()
        {
            AssignTesterResponse res = new AssignTesterResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select distinct(t.crf_id) from qa_project_details t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            List<SelectListItem> clist = new List<SelectListItem>();

            foreach (DataRow item in dt.Rows)
            {

                clist.Add(new SelectListItem { Text = item["crf_id"].ToString(), Value = item["crf_id"].ToString() });
            }
            res.Crf_Id= clist;

            return res;
        }
        public AssignTesterNameResponse Fetchalltestername()
        {
            AssignTesterNameResponse res = new AssignTesterNameResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select distinct(t.team_mem),e.emp_name from time_sheet_tl t ,employee_master e where t.team_mem=e.emp_code and t.tl_id=100188";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public AssignCrfToTesterResponse Insert_AssignCrftoTester(AssignCrfToTesterRequest requ)
        {
          
            AssignCrfToTesterResponse _assignCrfToTesterResponse = new AssignCrfToTesterResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();


            cmd.CommandText = "UPDATE qa_project_details t SET t.tester_id ='"+requ.Tester_id+"' WHERE t.crf_id = '"+requ.Crf_id+"'";
                var i = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                if (i == 1)
                {
                _assignCrfToTesterResponse.Result = "1";
                }
                else
                {
                _assignCrfToTesterResponse.Result = "0";
                }
            


            // modelforSeverityResponse.Data = JsonConvert.SerializeObject(dt);

            return _assignCrfToTesterResponse;
        }
        public Prioritynamefetchingresponse Fetchallpriorityname()
        {
            Prioritynamefetchingresponse res = new Prioritynamefetchingresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.priority_id,t.priority_name from qa_priority_master t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public Trackernamefetchingresponse Fetchalltrackername()
        {
            Trackernamefetchingresponse res = new Trackernamefetchingresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.tracker_id,t.tracker_name from qa_tracker_master t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public Severitynamefetchingresponse Fetchallseverityname()
        {
            Severitynamefetchingresponse res = new Severitynamefetchingresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select s.id,s.severity_name from qa_severity_master s";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public Defectsnamefetchingresponse Fetchalldefectsname()
        {
            Defectsnamefetchingresponse res = new Defectsnamefetchingresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select d.defects_id,d.defects_name from qa_defects d";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public Techleadnamefetchingresponse Fetchalltechleadname()
        {
            Techleadnamefetchingresponse res = new Techleadnamefetchingresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select  distinct (t.tl_id),e.emp_name from time_sheet_tl t,employee_master e where t.tl_id=e.emp_code";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public ViewIssuesGridResponse Fetchallissuesforview_Tester(ViewIssuesGridRequest req)
        {

            ViewIssuesGridResponse res = new ViewIssuesGridResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();

            cmd.CommandText = "select t.assign_id,p.crf_id PROJECT,m.tracker_name,p.status_name,j.priority_name,n.severity_name,t.subject,t.assignee,e.emp_name TESTER,sysdate,t.percentage_done,t.developer ,ee.emp_name from qa_assign_issue t, qa_project_details p,qa_tracker_master m, QA_DEFECT_STATUS p,qa_priority_master j, qa_severity_master n,employee_master e, employee_master ee where t.project_id = p.proid and t.tracker = m.tracker_id and t.status = p.status_id and t.priority = j.priority_id and t.severity = n.id AND t.assignee = e.emp_code and t.developer = ee.emp_code and t.project_id='"+req.Project_Id+"' "; 
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            res.ViewIssues = JsonConvert.SerializeObject(dt);
            return res;

        }




        public IssueUpdatedetailsresponse IssueUpdatedetailsresponse(IssueUpdatedetailsrequest req)
        {
            IssueUpdatedetailsresponse response = new IssueUpdatedetailsresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.assign_id,p.crf_id PROJECT,m.tracker_name,p.status_name,j.priority_name,n.severity_name,t.subject,t.assignee,e.emp_name TESTER,sysdate,t.percentage_done,t.developer ,ee.emp_name,t.application_techlead,em.emp_name,t.firm,l.firm_name from qa_assign_issue t,qa_project_details p,qa_tracker_master m,QA_DEFECT_STATUS p,qa_priority_master j,qa_severity_master n,employee_master e,employee_master ee ,employee_master em,time_sheet_cl_dtl l where t.project_id = p.proid and t.tracker = m.tracker_id and t.status = p.status_id and t.priority = j.priority_id and t.severity = n.id AND t.assignee = e.emp_code and t.developer = ee.emp_code and t.application_techlead = em.emp_code and t.firm = l.firm_id and t.assign_id = '"+req.Bug_id+"'";
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            response.assign_id= Convert.ToInt32(dt.Rows[0][0]);
            response.Subject = dt.Rows[0][6].ToString();
            response.Assignee = dt.Rows[0][8].ToString();
            response.Start_Date = dt.Rows[0][9].ToString();
            response.Application_Techlead = dt.Rows[0][14].ToString();
            response.Developer = dt.Rows[0][12].ToString();
            response.Firm = dt.Rows[0][16].ToString();
         
            return response;
        }
        public ViewIssuedetailsresponse ViewIssuedetails(ViewIssuedetailsrequest req)
        {
            ViewIssuedetailsresponse response = new ViewIssuedetailsresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.assign_id,p.crf_id PROJECT,m.tracker_name,p.status_name,j.priority_name,n.severity_name,t.subject,t.assignee,e.emp_name TESTER,sysdate,t.percentage_done,t.developer ,ee.emp_name,t.application_techlead,em.emp_name,t.firm,l.firm_name from qa_assign_issue t,qa_project_details p,qa_tracker_master m,QA_DEFECT_STATUS p,qa_priority_master j,qa_severity_master n,employee_master e,employee_master ee ,employee_master em,time_sheet_cl_dtl l where t.project_id = p.proid and t.tracker = m.tracker_id and t.status = p.status_id and t.priority = j.priority_id and t.severity = n.id AND t.assignee = e.emp_code and t.developer = ee.emp_code and t.application_techlead = em.emp_code and t.firm = l.firm_id and t.assign_id = '" + req.Bug_id + "'";
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            response.assign_id = Convert.ToInt32(dt.Rows[0][0]);
            response.Tracker = dt.Rows[0][2].ToString();
            response.Status = dt.Rows[0][3].ToString();
            response.Priority = dt.Rows[0][4].ToString();
            response.Severity = dt.Rows[0][5].ToString();
            response.Assignee = dt.Rows[0][8].ToString();
            response.Firm = dt.Rows[0][16].ToString();

            response.Application_Techlead = dt.Rows[0][14].ToString();
           
            return response;
        }
        public Statusnamefetchingresponse Fetchstatusdetails()
        {
            Statusnamefetchingresponse res = new Statusnamefetchingresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.status_id,t.status_name from qa_defect_status t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public FilterGridViewModelResponse Fetchgridbyfiltering(FilterGridViewModelRequest req)
        {

            FilterGridViewModelResponse res = new FilterGridViewModelResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
             
            cmd.CommandText = "select t.assign_id,p.crf_id PROJECT,m.tracker_name,t.status,p.status_name,j.priority_name,n.severity_name,t.subject,t.assignee,e.emp_name TESTER,sysdate,t.percentage_done,t.developer ,ee.emp_name from qa_assign_issue t, qa_project_details p,qa_tracker_master m, QA_DEFECT_STATUS p,qa_priority_master j, qa_severity_master n,employee_master e, employee_master ee where t.project_id = p.proid and t.tracker = m.tracker_id and t.status = p.status_id and t.priority = j.priority_id and t.severity = n.id AND t.assignee = e.emp_code and t.developer = ee.emp_code and t.project_id='" + req.Project_Id + "' and t.status= '"+ req.Statuspartial + "'";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            res.Data = JsonConvert.SerializeObject(dt);
            return res;

        }
        public FetchDeveloperbytlidresponse Fetchalldevelopernamesby_tlid()
        {
            FetchDeveloperbytlidresponse res = new FetchDeveloperbytlidresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select l.team_mem,e.emp_name from time_sheet_tl l,employee_master e where l.team_mem=e.emp_code and  l.tl_id in(100177,100231,100441)";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            List<SelectListItem> clist = new List<SelectListItem>();

            foreach (DataRow item in dt.Rows)
            {

                clist.Add(new SelectListItem { Text = item["emp_name"].ToString(), Value = item["team_mem"].ToString() });
            }
            res.Developer_name = clist;

            return res;
        }



        public ExcelModelExportResponse Exportexcelfromdb(ExcelModelExportRequest req)
        {
            ExcelModelExportResponse response = new ExcelModelExportResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select e.emp_name,p.type_name,v.issue_name,t.application_link,i.issue_description,i.risk_impact,i.remediation,t.assigned_date,t.recomended_date,ee.emp_name,r.risk_name from vapt_assigned_issues t,vapt_issues v,vapt_risk_master r,time_sheet_project p,employee_master e,employee_master ee,vapt_issues i where t.issue_id=v.issue_id and t.risk_rating=r.risk_id and t.project_id=p.type_id and t.techlead_id=e.emp_code and t.tester_id=ee.emp_code and t.issue_id=i.issue_id";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
           
            cmd.Connection.Close();
            response.Data = JsonConvert.SerializeObject(dt);

            return response;
        }
        public BillingModelOnloadResponse Fetchallitem()
        {
            BillingModelOnloadResponse res = new BillingModelOnloadResponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();

            cmd.CommandText = "select t.item_id,t.item_name from ITEM_LIST_887 t";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            res.Data = JsonConvert.SerializeObject(dt);
            return res;
           
        }
        public Billingfetchdetailsresponse FetchallitemsGrid(Billingfetchdetailsrequest req)
        {
            Billingfetchdetailsresponse res = new Billingfetchdetailsresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select t.item_id,t.item_name,t.item_rate,t.item_tax_rate,('"+req.Item_quantity+"'*t.item_rate) as Total_amount,('"+req.Item_quantity+"'*t.item_tax_rate) as Total_Tax from ITEM_LIST_887 t where t.item_id='"+req.item_id+"'";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();

            res.Data = JsonConvert.SerializeObject(dt);
            return res;
        }
        public fetchloandetailsresponse getloandetails(fetchloandetailsrequest req)
        {
            fetchloandetailsresponse res = new fetchloandetailsresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();

            cmd.CommandText = "select h.product,h.loandate,h.customer_id,h.customer_name,h.last_transaction_date,h.loan_no from LOAN_MASTER_887 h where h.loan_no='" + req.loanno+"'";
            cmd.CommandType = CommandType.Text;
            OracleDataAdapter adr = new OracleDataAdapter(cmd);
            adr.Fill(dt);
            cmd.Connection.Close();
            res.product = dt.Rows[0][0].ToString();
            res.loandate = dt.Rows[0][1].ToString();
            res.customerid= dt.Rows[0][2].ToString();
            res.customer_name = dt.Rows[0][3].ToString();
            res.transactiondate= dt.Rows[0][4].ToString();
            res.loanno = dt.Rows[0][5].ToString();
            return res;

        }
        public Insertloandetailsresponse Insertloandetails(Insertloandetailsrequest requ)
        {
            int idval = 0;
            Insertloandetailsresponse _Response = new Insertloandetailsresponse();
            DataTable dt = new DataTable();
            cmd.Connection = db_.Connect();
            cmd.CommandText = "select max(INSTALLMENTNO) from LOAN_INSTALLMENT_DTL_887";
            var a = cmd.ExecuteScalar();

            if (a == null)
            {
                idval = 1;
            }
            else
            {
                idval = Convert.ToInt32(a) + 1;
            }
            
                cmd.Connection = db_.Connect();
            string efecdate = (requ.effectivedate).ToString();
            string insdate = (requ.loandate).ToString();
                cmd.CommandText = "insert into loan_installment_dtl_887(loanno,installmentno,installment_amount,effective_date,payment_mode,instrument_date,instrument_ref_no,staff_name,branch_name) values('"+requ.loanno+"','" + idval + "','"+requ.amount+ "','" + efecdate + "','" + requ.mode+"','"+insdate+ "','"+requ.refno+"','"+requ.staff+"','"+requ.branch+"')";
                var i = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                if (i == 1)
                {
                    _Response.Result = 1;
                }
                else
                {
                    _Response.Result = 0;
                }
            


           

            return _Response;
        }


    }
}
