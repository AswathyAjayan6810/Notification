﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class BillingModel
    {
    }
    public class BillingModelOnloadRequest
    {
        public string Functionid { get; set; }

    }
    public class BillingModelOnloadResponse
    {
        public string Data { get; set; }
        public IEnumerable<SelectListItem> Item_list { get; set; }
    }
    public class Billingfetchdetailsrequest
    {
        public string item_id { get; set; }
        public int Item_quantity { get; set; }
    }
    public class Billingfetchdetailsresponse
    {
        public string Data { get; set; }
    }
}
