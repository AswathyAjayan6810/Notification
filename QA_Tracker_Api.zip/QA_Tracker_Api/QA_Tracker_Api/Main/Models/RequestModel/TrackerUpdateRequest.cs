﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models.RequestModel
{
    public class TrackerUpdateRequest
    {

        public int Tracker_id { get; set; }
        public string Tracker_name { get; set; }
    }
}
