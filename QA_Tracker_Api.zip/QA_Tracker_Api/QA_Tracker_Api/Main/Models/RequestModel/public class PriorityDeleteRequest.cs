﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models.RequestModel
{
    public class public_class_PriorityDeleteRequest
    {

        public int Priority_id { get; set; }
        public string Priority_name { get; set; }
    }
}
