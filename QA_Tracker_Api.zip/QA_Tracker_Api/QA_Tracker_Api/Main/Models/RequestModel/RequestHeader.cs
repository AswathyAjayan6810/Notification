﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models.RequestModel
{
    public class RequestHeader
    {

        private string _JwtToken;
        private string _hash;
        private string _Role;

        public string JwtToken { get => _JwtToken; set => _JwtToken = value; }

        public string Hash { get => _hash; set => _hash = value; }

        public string Role { get => _Role; set => _Role = value; }
    }
}
