﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models.RequestModel
{
    public class ProjectModelforFetchCrfidRequest: RequestHeader
    {
        public string FunctionId { get; set; }
    }
}
