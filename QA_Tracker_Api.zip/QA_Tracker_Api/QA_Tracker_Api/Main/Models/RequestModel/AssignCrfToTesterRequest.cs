﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models.RequestModel
{
    public class AssignCrfToTesterRequest
    {
        public int Crf_id { get; set; }
        public int Tester_id { get; set; }
    }
}
