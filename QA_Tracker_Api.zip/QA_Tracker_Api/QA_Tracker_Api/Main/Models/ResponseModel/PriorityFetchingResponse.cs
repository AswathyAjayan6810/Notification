﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models.ResponseModel
{
    public class PriorityFetchingResponse
    {
        public IEnumerable<SelectListItem> Priority_name { get; set; }
    }
}
