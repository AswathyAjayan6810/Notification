﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models.ResponseModel
{
    public class TrackerUpdateResponse
    {
        public int Result { get; set; }
    }
}
