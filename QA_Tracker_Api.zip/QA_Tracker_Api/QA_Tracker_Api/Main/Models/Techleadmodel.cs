﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class Techleadmodel
    {
    }
    public class Techleadnamefetchingrequest
    {
        public string FunctionId { get; set; }
    }
    public class Techleadnamefetchingresponse
    {
        public string Data { get; set; }
    }
}
