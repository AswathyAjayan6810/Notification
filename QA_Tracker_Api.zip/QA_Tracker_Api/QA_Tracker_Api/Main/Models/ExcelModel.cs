﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class ExcelModel
    {
    }
    public class ExcelModelExportRequest
    {
        public string Functionid { get; set; }
    }

    public class ExcelModelExportResponse
    {
        public string Data { get; set; }
    }
}
