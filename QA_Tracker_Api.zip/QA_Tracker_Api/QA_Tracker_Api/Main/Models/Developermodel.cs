﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class Developermodel
    {
    }
    public class FetchDeveloperbytlidrequest
    {
        public string FunctionId { get; set; }
    }
    public class FetchDeveloperbytlidresponse
    {
        public IEnumerable<SelectListItem> Developer_name { get; set; }
        public string viewbagmessage { get; set; }
    }
}
