﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class Statusmodel
    {
    }
    public class Statusnamefetchingrequest
    {
        public string FunctionId { get; set; }
    }
    public class Statusnamefetchingresponse
    {
        public string Data { get; set; }
    }
}
