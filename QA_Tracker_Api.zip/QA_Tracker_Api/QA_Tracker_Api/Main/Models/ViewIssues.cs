﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class ViewIssues
    {
    }
    public class ViewIssuesGridRequest
    {

        public int Project_Id { get; set; }
    }
    public class ViewIssuesGridResponse
    {
        public string ViewIssues { get; set; }
    }
    public class IssueUpdatedetailsrequest
    {
        public int Bug_id { get; set; }
    }
    public class IssueUpdatedetailsresponse
    {
        public int assign_id { get; set; }
        public int Tracker { get; set; }
        public string Subject { get; set; }
        public int Status { get; set; }
        public int Priority { get; set; }
        public string Assignee { get; set; }
        public string Start_Date { get; set; }

        public string Due_Date { get; set; }
        public string Estimated_Time { get; set; }
        public int Severity { get; set; }
        public string Application_Techlead { get; set; }
        public string Developer { get; set; }
        public string Firm { get; set; }
        public string Target_Date { get; set; }
        public int Defect_Categorization { get; set; }
        public string MyProperty { get; set; }
       
        public string Percentage_Done { get; set; }
    }
    public class ViewIssuedetailsrequest
    {
        public string Bug_id { get; set; }
    }
    public class ViewIssuedetailsresponse
    {
        public int assign_id { get; set; }
        public string Tracker { get; set; }
        public string Subject { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }
        public string Assignee { get; set; }
        public string Start_Date { get; set; }

        public string Due_Date { get; set; }
        public string Estimated_Time { get; set; }
        public string Severity { get; set; }
        public string Application_Techlead { get; set; }
        public string Developer { get; set; }
        public string Firm { get; set; }
        public string Target_Date { get; set; }
        public int Defect_Categorization { get; set; }
        public string MyProperty { get; set; }
      
        public string Percentage_Done { get; set; }
    }
}
