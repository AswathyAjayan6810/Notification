﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class FilterGridViewModel
    {
    }
    public class FilterGridViewModelRequest
    {
        public int Project_Id { get; set; }
        public string Statuscheck { get; set; }
        public string Statusdrop { get; set; }
        public string Statuspartial { get; set; }
    }
    public class FilterGridViewModelResponse
    {
        public string Data { get; set; }
    }
}
