﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Models
{
    public class Loaninstallment
    {

        public string loanno { get; set; }
        public string product { get; set; }
        public string loandate { get; set; }
        public string customerid { get; set; }
        public string customer_name { get; set; }
        public string transactiondate { get; set; }
    }


    public class fetchbranchnamerequet
    {
        public string functionid { get; set; }
    }
    public class fetchbranchnameresponse
    {
        public string branchnames { get; set; }
    }
    public class fetchloandetailsrequest
    {
        public string loanno { get; set; }
    }
    public class fetchloandetailsresponse
    {
        public string loanno { get; set; }
        public string product { get; set; }
        public string loandate { get; set; }
        public string customerid { get; set; }
        public string customer_name { get; set; }
        public string transactiondate { get; set; }
        public string Data { get; set; }

    }
    public class Insertloandetailsrequest
    {
        public string loanno { get; set; }
        public string product { get; set; }
        public string loandate { get; set; }
        public string customerid { get; set; }
        public string customer_name { get; set; }
        public string transactiondate { get; set; }
        public string amount { get; set; }
        public string effectivedate { get; set; }
        public string mode { get; set; }
        public string inst_date { get; set; }
        public string refno { get; set; }
        public string staff { get; set; }
        public string branch { get; set; }
    }
    public class Insertloandetailsresponse
    {

        public int Result { get; set; }
    }

}