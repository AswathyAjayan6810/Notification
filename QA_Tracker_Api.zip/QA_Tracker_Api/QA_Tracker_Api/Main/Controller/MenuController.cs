﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QA_Tracker_Api.Main.Models.RequestModel;
using QA_Tracker_Api.Main.Models.ResponseModel;
using QA_Tracker_Api.Common;
using QA_Tracker_Api.Main.BLL;

namespace QA_Tracker_Api.Main.Controller
{
    [Route("api/Main/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        QueryClass qry = new QueryClass();



        [HttpPost("FetchAllMenuForEmpcode")]
        public ActionResult<ModelforEmpcodeResponse> FetchMenu([FromBody] ModelforEmpcodeRequest req)
        {

            BaseApi baseApi = new BaseApi(req);
            int IsHashCorrect = baseApi.Validate_Hash();
            int IsTokenValid = baseApi.Validate_Token();
           // bool IsAValidUser = baseApi.Validate_Role("Tester");

            if (ModelState.IsValid && IsHashCorrect == 1 && IsTokenValid == 1)
            {
               ModelforEmpcodeResponse empcodeResponse = qry.Fetch_menu_for_Empcode(req);
                return Ok(empcodeResponse);
            }
            else
            {
                return BadRequest(ModelState);
            }


        }

        [HttpPost("FetchAllCrfId")]
        public ActionResult<ProjectModelforFetchCrfidResponse> FetchAllCrfId([FromBody] ProjectModelforFetchCrfidRequest req)
        {

            BaseApi baseApi = new BaseApi(req);
            int IsHashCorrect = baseApi.Validate_Hash();
            int IsTokenValid = baseApi.Validate_Token();
           // bool IsAValidUser = baseApi.Validate_Role("Tester");

            if (ModelState.IsValid && IsHashCorrect == 1 && IsTokenValid == 1)
            {
                ProjectModelforFetchCrfidResponse pres = qry.Crf_id_Details();

                return Ok(pres);


            }
            else
            {
                return BadRequest(ModelState);
            }


        }

        [HttpPost("FetchAllDetailsforCrfId")]
        public ActionResult<ProjectModelforDeatilsofCrfidResponse> FetchAllDetailsforCrfId([FromBody] ProjectModelforDeatilsofCrfidRequest req)
        {

            BaseApi baseApi = new BaseApi(req);
            int IsHashCorrect = baseApi.Validate_Hash();
            int IsTokenValid = baseApi.Validate_Token();
            // bool IsAValidUser = baseApi.Validate_Role("Tester");

            if (ModelState.IsValid && IsHashCorrect == 1 && IsTokenValid == 1)
            {
                ProjectModelforDeatilsofCrfidResponse pres = qry.FetchAllDetailsforCrfId(req);

                return Ok(pres);


            }
            else
            {
                return BadRequest(ModelState);
            }


        }


    }
}
