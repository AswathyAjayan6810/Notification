﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QA_Tracker_Api.Main.Models.RequestModel;
using QA_Tracker_Api.Main.Models.ResponseModel;
using QA_Tracker_Api.Main.BLL;
using QA_Tracker_Api.Main.Models;


namespace QA_Tracker_Api.Main.Controller
{
    [Route("api/Main/[controller]")]
    [ApiController]
    public class TesterController : ControllerBase
    {
        QueryClass qry = new QueryClass();

        [HttpPost("Fetchallpriority")]
        public ActionResult<PriorityFetchingResponse> Fetchallpriority([FromBody] PriorityFetchingRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                PriorityFetchingResponse vres = qry.PriorityDetailsforAdmin();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }


        [HttpPost("View_Issues_Grid")]
        public ActionResult<ViewIssuesGridResponse> View_Issues_Grid([FromBody] ViewIssuesGridRequest req)
        {
            
            if (ModelState.IsValid == true)
            {

                ViewIssuesGridResponse vres = qry.Fetchallissuesforview_Tester(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }


        [HttpPost("Fetchissueeditdetails")]
        public ActionResult<IssueUpdatedetailsresponse> Fetchissueeditdetails([FromBody] IssueUpdatedetailsrequest req)
        {
           
            if (ModelState.IsValid == true)
            {

                IssueUpdatedetailsresponse vres = qry.IssueUpdatedetailsresponse(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }

        }
        [HttpPost("FetchviewissueDetails ")]
        public ActionResult<ViewIssuedetailsresponse> FetchviewissueDetails([FromBody] ViewIssuedetailsrequest req)
        {
           
            if (ModelState.IsValid == true)
            {

                ViewIssuedetailsresponse vres = qry.ViewIssuedetails(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }
        [HttpPost("Fetchallstatusnamesforassign")]
        public ActionResult<Statusnamefetchingresponse> Fetchallstatusnamesforassign([FromBody] Statusnamefetchingrequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                Statusnamefetchingresponse vres = qry.Fetchstatusdetails();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }

        }
        [HttpPost("Fetchviewissuegridbyfiltering")]
        public ActionResult<FilterGridViewModelResponse> Fetchviewissuegridbyfiltering([FromBody] FilterGridViewModelRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                FilterGridViewModelResponse vres = qry.Fetchgridbyfiltering(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }

        }
       
    }


}
