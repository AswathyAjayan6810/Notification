﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QA_Tracker_Api.Main.BLL;
using QA_Tracker_Api.Main.Models.RequestModel;
using QA_Tracker_Api.Main.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using QA_Tracker_Api.Main.Models;


namespace QA_Tracker_Api.Main.Controller
{
    [Route("api/Main/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {

        QueryClass qry = new QueryClass();
        [HttpPost("Add_Priority")]

        public ActionResult<PriorityModelResponse> Add_Priority([FromBody] PriorityModelRequest req)
        {


            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            // int isuserlogedin = baseApi.IsUserLog();
            // if (ModelState.IsValid && IsHashCorrect == 1 && IsTokenValid == 1 && IsAValidUser == true && isuserlogedin == 1)
            if (ModelState.IsValid == true)
            {
                PriorityModelResponse res = qry.Add_Priority(req);

                //var ResponseStringForHashing = JsonConvert.SerializeObject(req);
                //res.Hash = _Hashing.CreateHash(ResponseStringForHashing);
                //DateTime _currentTime = new DateTime();
                //_currentTime = Convert.ToDateTime(DateTime.Now);
                //res.JwtToken = TokenManager.GenerateToken(_currentTime.ToString(),5);
                return Ok(res);
            }
            else
            {
                PriorityModelResponse res = new PriorityModelResponse();
                res.Result = "Wrong Request";
                return Ok(res);
            }
        }
        [HttpPost("Fetchallpriority")]
        public ActionResult<PriorityFetchingResponse> Fetchallpriority([FromBody] PriorityFetchingRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                PriorityFetchingResponse vres = qry.PriorityDetailsforAdmin();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }


        [HttpPost("Fetchallpriorityfordelete")]
        public ActionResult<PriorityFetchingfordeleteResponse> Fetchallpriorityfordelete([FromBody] PriorityFetchingfordeleteRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                PriorityFetchingfordeleteResponse vres = qry.PriorityDetailsforAdminfordelete();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }


        [HttpPost("FetchpriorityDetails")]
        public ActionResult<PriorityEditDetailsResponse> FetchpriorityDetails([FromBody] PriorityEditDetailsRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                PriorityEditDetailsResponse vres = qry.FetchPriorityDetailWithID(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }

        }



        [HttpPost("UpdatePriorityWithId")]
        public ActionResult<PriorityUpdateResponse> UpdatePriorityWithId([FromBody] PriorityUpdateRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            QueryClass qry = new QueryClass();

            if (ModelState.IsValid == true)
            {

                PriorityUpdateResponse res = qry.getUpdatePriority(req);
                return Ok(res);


            }
            else
            {
                return BadRequest(ModelState);
            }



        }
        [HttpPost("Deletepioritywithid")]
        public ActionResult<PriorityDeleteResponse> Deletepioritywithid([FromBody] PriorityDeleteRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            QueryClass qry = new QueryClass();

            if (ModelState.IsValid == true)
            {

                PriorityDeleteResponse res = qry.getDeletePriority(req);
                return Ok(res);


            }
            else
            {
                return BadRequest(ModelState);
            }


                 
        }

        [HttpPost("Add_Tracker")]

        public ActionResult<TrackerModelResponse> Add_Tracker([FromBody] TrackerModelRequest req)
        {


            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            // int isuserlogedin = baseApi.IsUserLog();
            // if (ModelState.IsValid && IsHashCorrect == 1 && IsTokenValid == 1 && IsAValidUser == true && isuserlogedin == 1)
            if (ModelState.IsValid == true)
            {
                TrackerModelResponse res = qry.Add_Tracker(req);

                //var ResponseStringForHashing = JsonConvert.SerializeObject(req);
                //res.Hash = _Hashing.CreateHash(ResponseStringForHashing);
                //DateTime _currentTime = new DateTime();
                //_currentTime = Convert.ToDateTime(DateTime.Now);
                //res.JwtToken = TokenManager.GenerateToken(_currentTime.ToString(),5);
                return Ok(res);
            }
            else
            {
                TrackerModelResponse res = new TrackerModelResponse();
                res.Result = "Wrong Request";
                return Ok(res);
            }
        }
        [HttpPost("Fetchalltrackernames")]
        public ActionResult<TrackerFetchingResponse> Fetchalltrackernames([FromBody] TrackerFetchingRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                TrackerFetchingResponse vres = qry.TrackerDetailsforAdmin();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }
        [HttpPost("FetchtrackerDetails")]
        public ActionResult<TrackerEditDetailsResponse> FetchtrackerDetails([FromBody] TrackerEditDetailsRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                TrackerEditDetailsResponse vres = qry.FetchTrackerDetailWithID(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }

        }

        [HttpPost("UpdateTrackerWithId")]
        public ActionResult<TrackerUpdateResponse> UpdateTrackerWithId([FromBody] TrackerUpdateRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            QueryClass qry = new QueryClass();

            if (ModelState.IsValid == true)
            {

                TrackerUpdateResponse res = qry.getUpdateTracker(req);
                return Ok(res);
            }
            else
            {
                return BadRequest(ModelState);
            }



        }
        [HttpPost("Fetchalltrackerfordelete")]
        public ActionResult<TrackerFetchingfordeleteResponse> Fetchalltrackerfordelete([FromBody] TrackerFetchingfordeleteRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                TrackerFetchingfordeleteResponse vres = qry.TrackerDetailsforAdminfordelete();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }


        [HttpPost("DeleteTrackerwithid")]
        public ActionResult<TrackerDeleteResponse> DeleteTrackerwithid([FromBody] TrackerDeleteRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            QueryClass qry = new QueryClass();

            if (ModelState.IsValid == true)
            {

                TrackerDeleteResponse res = qry.getDeleteTracker(req);
                return Ok(res);


            }
            else
            {
                return BadRequest(ModelState);
            }



        }
        [HttpPost("Fetchallcrfid")]
        public ActionResult<AssignTesterResponse> Fetchallcrfid([FromBody] AssignTesterRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                AssignTesterResponse vres = qry.fetchallcrfid();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }

        [HttpPost("FetchallTesternames")]
        public ActionResult<AssignTesterNameResponse> FetchallTesternames([FromBody] AssignTesterNameRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                AssignTesterNameResponse vres = qry.Fetchalltestername();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }

        [HttpPost("AssignTester")]
        public ActionResult<AssignCrfToTesterResponse> AssignTester([FromBody] AssignCrfToTesterRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Tester");


            if (ModelState.IsValid == true)
            {
                AssignCrfToTesterResponse vres = qry.Insert_AssignCrftoTester(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }


        }
        [HttpPost("FetchallPrioritynamesforassign")]
        public ActionResult<Prioritynamefetchingresponse> FetchallPrioritynamesforassign([FromBody] Prioritynamefetchingrequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                Prioritynamefetchingresponse vres = qry.Fetchallpriorityname();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }
        [HttpPost("FetchallTrackernamesforassign")]
        public ActionResult<Trackernamefetchingresponse> FetchallTrackernamesforassign([FromBody] Trackernamefetchingrequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                Trackernamefetchingresponse vres = qry.Fetchalltrackername();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }
        [HttpPost("FetchallSeveritynamesforassign")]
        public ActionResult<Severitynamefetchingresponse> FetchallSeveritynamesforassign([FromBody] Severitynamefetchingrequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                Severitynamefetchingresponse vres = qry.Fetchallseverityname();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }
        [HttpPost("Fetchalldefectsnamesforassign")]
        public ActionResult<Defectsnamefetchingresponse> Fetchalldefectsnamesforassign([FromBody] Defectsnamefetchingrequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                Defectsnamefetchingresponse vres = qry.Fetchalldefectsname();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }
        [HttpPost("Fetchalltechleadnames")]
        public ActionResult<Techleadnamefetchingresponse> Fetchalltechleadnames([FromBody] Techleadnamefetchingrequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                Techleadnamefetchingresponse vres = qry.Fetchalltechleadname();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }
        [HttpPost("Fetchalldevelopernamesbytlid")]
        public ActionResult<FetchDeveloperbytlidresponse> Fetchalldevelopernamesbytlid([FromBody] FetchDeveloperbytlidrequest req)
        {

            if (ModelState.IsValid == true)
            {

                FetchDeveloperbytlidresponse vres = qry.Fetchalldevelopernamesby_tlid();

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }
        }
        [HttpPost("FetchAllDetailsofLoan")]
        public ActionResult<fetchloandetailsresponse> FetchAllDetailsofLoan([FromBody] fetchloandetailsrequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            QueryClass qry = new QueryClass();

            if (ModelState.IsValid == true)
            {

                fetchloandetailsresponse res = qry.getloandetails(req);
                return Ok(res);


            }
            else
            {
                return BadRequest(ModelState);
            }



        }
        [HttpPost("Insertloandetails")]
        public ActionResult<Insertloandetailsresponse> Insertloandetails([FromBody] Insertloandetailsrequest req)
        {
           
            QueryClass qry = new QueryClass();

            if (ModelState.IsValid == true)
            {

                Insertloandetailsresponse res = qry.Insertloandetails(req);
                return Ok(res);


            }
            else
            {
                return BadRequest(ModelState);
            }



        }
    }
}
