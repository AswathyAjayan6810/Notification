﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QA_Tracker_Api.Main.BLL;
using QA_Tracker_Api.Main.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Controller
{
    [Route("api/Main/[controller]")]
    [ApiController]
    public class ExcelController : ControllerBase
    {
        QueryClass qry = new QueryClass();
       
        [HttpPost("ExportExcel")]

       
        public ActionResult<ExcelModelExportResponse> ExportExcel([FromBody] ExcelModelExportRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid == true)
            {

                ExcelModelExportResponse vres = qry.Exportexcelfromdb(req);

                return Ok(vres);


            }
            else
            {
                return BadRequest(ModelState);
            }




        }

    }
}
