﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QA_Tracker_Api.Main.BLL;
using QA_Tracker_Api.Main.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Main.Controller
{
    [Route("api/Main/[controller]")]
    [ApiController]
    public class BillingController : ControllerBase
    {
        QueryClass qry = new QueryClass();
        [HttpPost("FetchAllItem")]
        public ActionResult<BillingModelOnloadResponse> FetchAllItem([FromBody] BillingModelOnloadRequest req)
        {
            //BaseApi baseApi = new BaseApi(req);
            //int IsHashCorrect = baseApi.Validate_Hash();
            //int IsTokenValid = baseApi.Validate_Token();
            //bool IsAValidUser = baseApi.Validate_Role("Admin");
            if (ModelState.IsValid)
            {

                BillingModelOnloadResponse res = qry.Fetchallitem();
                return Ok(res);


            }
            else
            {
                return BadRequest(ModelState);
            }

        }
        [HttpPost("FetchAllItemsGrid")]
        public ActionResult<Billingfetchdetailsresponse> FetchAllItemsGrid([FromBody] Billingfetchdetailsrequest req)
        {
           
            if (ModelState.IsValid)
            {

                Billingfetchdetailsresponse res = qry.FetchallitemsGrid(req);
                return Ok(res);


            }
            else
            {
                return BadRequest(ModelState);
            }

        }
    }
}
