﻿using Newtonsoft.Json;
using QA_Tracker_Api.Main.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Common
{
    public class BaseApi
    {

        RequestHeader requestHeader = new RequestHeader();
        private string _Hash;
        private string _jwtToken;
        private string _Role;
        private string Hashed_Data;
        public string Host = "10.192.5.42";
        public int port = 6379;
        //public string keyname = AESEngine.EncryptAndEncode("10009");
        public BaseApi(object req)
        {

            requestHeader = (RequestHeader)req;
            _Hash = requestHeader.Hash;
            requestHeader.Hash = null;
            _jwtToken = requestHeader.JwtToken;
            requestHeader.JwtToken = null;

            _Role = requestHeader.Role;
            requestHeader.Role = null;


            Security _Hashing = new Security();
            var RequestStringForHashing = JsonConvert.SerializeObject(requestHeader);
            Hashed_Data = _Hashing.CreateHash(RequestStringForHashing);

        }

        public int Validate_Hash()
        {





            if (_Hash == Hashed_Data)
            {

                return 1;
            }
            else
            {

                return 0;
            }


        }

        public int Validate_Token()
        {





            string payload = TokenManager.ValidateToken(_jwtToken);
            if (payload != null)
            {

                return 1;
            }
            else
            {

                return 0;
            }


        }



        //public bool Validate_Role(string role)
        //{



        //    bool IsUserRoleAvailable = _Role.Contains(role);

        //    if (IsUserRoleAvailable == true)
        //    {

        //        return true;
        //    }
        //    else
        //    {

        //        return false;
        //    }


        //}
    }
}
