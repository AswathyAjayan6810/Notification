﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QA_Tracker_Api.Common
{
    public class Security
    {

        private string saltkey = "Salt key at the end of soucre text";
        public string CreateHash(string SourceText)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            if (String.IsNullOrEmpty(SourceText))
            {
                return String.Empty;
            }
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(SourceText + saltkey);
                byte[] hashBytes = md5.ComputeHash(inputBytes);


                string hex = BitConverter.ToString(hashBytes).Replace("-", "");


                return hex;

            }





        }


        public byte[] GenerateByteFromString(string SourceText)
        {
            if (String.IsNullOrEmpty(SourceText))
            {
                return null;
            }
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(SourceText + saltkey);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                return hashBytes;
            }


        }

        public byte[] GenerateByteFromHash(string hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);

            byte[] reverse = bytes;
            return reverse;
        }
    }
}
